<?php
  session_start();
  require("vendor/autoload.php");
  use PhpOffice\PhpSpreadsheet\Spreadsheet;
  use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

  $data_by_harga = $_SESSION['data_by_harga'];
  $data_by_urgensi = $_SESSION['data_by_urgensi'];

  $spreadsheet = new Spreadsheet();
  $sheet = $spreadsheet->getActiveSheet();
  $sheet->setCellValue('A1', 'Berdasarkan Urgensi');
  $sheet->setCellValue('A2', 'Nama Barang');
  $sheet->setCellValue('B2', 'Harga');
  $sheet->setCellValue('C2', 'Urgensi');
  $i = 3;

  foreach ($data_by_urgensi as $d) {
    $sheet->setCellValue('A'.$i, $d[0]);
    $sheet->setCellValue('B'.$i, $d[1]);
    $sheet->setCellValue('C'.$i, $d[2]);
    $i++;
  }
  $sheet->setCellValue('A'.$i, 'Berdasarkan Harga');
  $i++;
  $sheet->setCellValue('A'.$i, 'Nama Barang');
  $sheet->setCellValue('B'.$i, 'Harga');
  $sheet->setCellValue('C'.$i, 'Urgensi');
  $i++;

  foreach ($data_by_urgensi as $d) {
    $sheet->setCellValue('A'.$i, $d[0]);
    $sheet->setCellValue('B'.$i, $d[1]);
    $sheet->setCellValue('C'.$i, $d[2]);
    $i++;
  }

  $styleArray = [
    'borders' => [
      'allBorders' => [
        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
      ]
    ]
  ];
  $i = $i - 1;
  $sheet->getStyle('A1:C'.$i)->applyFromArray($styleArray);

  $file_name = rand(10,100)."-".date("Y-m-d");

  $writer = new Xlsx($spreadsheet);
  $writer->save('file_excel/'.$file_name.'.xlsx');
  header("location: file_excel/$file_name.xlsx");
?>
