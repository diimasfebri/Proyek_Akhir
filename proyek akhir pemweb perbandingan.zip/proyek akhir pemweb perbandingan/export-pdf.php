<?php
  session_start();
  require_once("dompdf/autoload.inc.php");
  use Dompdf\Dompdf;
  $dompdf = new Dompdf();
  $data_by_harga = $_SESSION['data_by_harga'];
  $data_by_urgensi = $_SESSION['data_by_urgensi'];
  $html = "<!DOCTYPE html>
  <html lang='en' dir='ltr'>
    <head>
      <meta charset='utf-8'>
      <title></title>
    </head>
    <body>
    <center>
      <h3>Berdasarkan Urgensi</h3>
    </center>
    <br>
    <table border='1' width='100%'>
      <tr>
        <th>Nama Barang</th>
        <th>Harga</th>
        <th>Urgensi</th>
      </tr>";

      foreach ($data_by_urgensi as $d) {
        $html .= "<tr>
          <td>".$d[0]."</td>
          <td>".$d[1]."</td>
          <td>".$d[2]."</td>
        </tr>";
      }

      $html .= "</table>
      <center>
        <h3>Berdasarkan Harga</h3>
      </center>
      <br>
      <table border='1' width='100%'>
        <tr>
          <th>Nama Barang</th>
          <th>Harga</th>
          <th>Urgensi</th>
        </tr>";

        foreach ($data_by_harga as $d) {
          $html .= "<tr>
            <td>".$d[0]."</td>
            <td>".$d[1]."</td>
            <td>".$d[2]."</td>
          </tr>";
        }

        $html .= "</table>
    </body>
  </html>";

  $dompdf->loadHtml($html);
  $dompdf->setPaper('A4', 'potrait');
  $dompdf->render();
  $dompdf->stream('laporan komparasi.pdf');
?>
