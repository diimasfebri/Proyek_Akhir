<!DOCTYPE HTML>
<html>
    <head>
        <title>Halaman Login</title>
        <link rel="stylesheet" href="style.css">
    </head>

    <body>
        <div class="wrapper">
        <div class="container1">
          <h1>Login</h1>
            <form action="loginact.php" method="post">
                <label for="Username">Username</label><br>
                <input type="text" name="username" id="username"><br>
                <label for="Password">Password</label><br>
                <input type="password" name="password" id="password"><br>
                <button>Log in</button>
                 <P><a href="register.php" class="register-a">Register</a></p>
            </form>
        </div>
        </div>

    </body>
</html>
