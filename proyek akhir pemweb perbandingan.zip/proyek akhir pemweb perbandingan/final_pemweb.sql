-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2021 at 12:43 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `final_pemweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_compare`
--

CREATE TABLE `tb_compare` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `saran_barang` varchar(100) NOT NULL,
  `tanggal_compare` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_compare`
--

INSERT INTO `tb_compare` (`id`, `id_user`, `saran_barang`, `tanggal_compare`) VALUES
(4, 1, 'c', '2021-06-17'),
(5, 1, 'c', '2021-06-17'),
(6, 1, 'c', '2021-06-17'),
(7, 1, 'c', '2021-06-17'),
(8, 1, 'c', '2021-06-17'),
(9, 1, 'c', '2021-06-17'),
(10, 1, 'c', '2021-06-17'),
(11, 1, 'c', '2021-06-17'),
(12, 1, 'c', '2021-06-17'),
(13, 1, 'c', '2021-06-17'),
(14, 1, 'c', '2021-06-17'),
(15, 1, 'c', '2021-06-17');

-- --------------------------------------------------------

--
-- Table structure for table `tb_compare_detail`
--

CREATE TABLE `tb_compare_detail` (
  `id` int(11) NOT NULL,
  `id_compare` int(11) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `harga_barang` int(11) NOT NULL,
  `urgensi_barang` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_compare_detail`
--

INSERT INTO `tb_compare_detail` (`id`, `id_compare`, `nama_barang`, `harga_barang`, `urgensi_barang`) VALUES
(1, 4, 'a', 12, 4),
(2, 4, 'b', 31, 3),
(3, 4, 'c', 23, 5),
(4, 5, 'a', 12, 4),
(5, 5, 'b', 31, 3),
(6, 5, 'c', 23, 5),
(7, 6, 'a', 12, 4),
(8, 6, 'b', 31, 3),
(9, 6, 'c', 23, 5),
(10, 7, 'a', 12, 4),
(11, 7, 'b', 31, 3),
(12, 7, 'c', 23, 5),
(13, 8, 'a', 12, 4),
(14, 8, 'b', 31, 3),
(15, 8, 'c', 23, 5),
(16, 9, 'a', 12, 4),
(17, 9, 'b', 31, 3),
(18, 9, 'c', 23, 5),
(19, 10, 'a', 12, 4),
(20, 10, 'b', 31, 3),
(21, 10, 'c', 23, 5),
(22, 11, 'a', 12, 4),
(23, 11, 'b', 31, 3),
(24, 11, 'c', 23, 5),
(25, 12, 'a', 12, 4),
(26, 12, 'b', 31, 3),
(27, 12, 'c', 23, 5),
(28, 13, 'a', 12, 4),
(29, 13, 'b', 31, 3),
(30, 13, 'c', 23, 5),
(31, 14, 'a', 12, 4),
(32, 14, 'b', 31, 3),
(33, 14, 'c', 23, 5),
(34, 15, 'a', 12, 4),
(35, 15, 'b', 31, 3),
(36, 15, 'c', 23, 5);

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id_user` bigint(20) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `username`, `password`, `nama`, `email`) VALUES
(1, 'admin', '12345', 'admin', 'admin@gmail.com'),
(2, 'bagastyanto', 'jaja', 'Fadilllah Tyanto Bagaskoro', 'fadillah.bagaskoro@gmail.com'),
(3, 'akira', '8888', 'deny', 'akiradeny@gmail.com'),
(4, 'risav', '9090', 'risav arrahman', 'risab@gmail.com'),
(5, 'arief', 'kaka', 'arief yahya', 'AriefYahyaP@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_compare`
--
ALTER TABLE `tb_compare`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_compare_detail`
--
ALTER TABLE `tb_compare_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_compare`
--
ALTER TABLE `tb_compare`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tb_compare_detail`
--
ALTER TABLE `tb_compare_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id_user` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
